## Start everything
docker-compose up -d

## Shutdown everything
docker-compose down

## Check logs 
docker-compose logs

## Check logs of sepcific service
docker-compose logs {serviceName}
e.g. docker-compose logs wmic-ctp

## Check logs with tail -f
docker-compose logs -f

## Check logs of sepcific service with tail -f
docker-compose logs -f {serviceName}
e.g. docker-compose logs -f wmic-ctp

## Remove single container
docker-compose rm -fsv {serviceName}
e.g. docker-compose rm -fsv wmb2b-is

## Start single container (if not running)
docker-compose up -d wmb2b-is

## Restart single container
docker-compose restart wmb2b-is

## Login into the container (using the compose)
docker-compose exec {serviceName} bash
e.g. docker-compose exec wmic-ctp bash

## Login into the container
docker container exec -it {containerName} bash
e.g. docker container exec -it wmb2b-is-wmb2b1 bash

## Copy file from host to container
docker cp {filename} {containerName}:{filePath in container}
e.g. docker cp dist.zip wmic-ctp:/opt/softwareag/profiles/CTP/workspace/webapps/b2b/

## Copy file from container to host
docker cp {containerName}:{filePath in container} {filename on host machine}
docker cp wmic-ctp:/opt/softwareag/profiles/CTP/workspace/webapps/b2b/WEB-INF/conf/sag-idm-config.json  sag-idm-config.json

## Some common paths
### B2B war dist folder
/opt/softwareag/profiles/CTP/workspace/webapps/b2b/
### B2B war lib folder
/opt/softwareag/profiles/CTP/workspace/webapps/b2b/WEB-INF/lib/
### B2B war conf folder
/opt/softwareag/profiles/CTP/workspace/webapps/b2b/WEB-INF/conf/

### B2B Server replicate folder
/opt/softwareag/IntegrationServer/instances/default/replicate/inbound/
