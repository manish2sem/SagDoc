# Copy certs in this directory
# Certs copied here will be used by CTP, IS, TC