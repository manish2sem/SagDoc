# Copy licenses in this directory
# licenses copied here will be used by CTP, IS, TC