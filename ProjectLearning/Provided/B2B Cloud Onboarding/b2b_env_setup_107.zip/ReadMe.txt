1. Increase your docker resources. Min 10 GB RAM
2. If the jvm fails to start in any container, adjust your resources.
3. Open PowerSHell and RUN setup.bat
4. Create a new IC Tenant with the following request.
EndPoint: https://www.shoa.com/integration/rest/admin/tenant
Body: {
    "integration": {
        "tenant": {
            "firstName": "Shobhit",
            "lastName": "Agarwal",
            "company": "b2b101",
            "country": "India",
            "state": "UP",
            "phone": "8888888881",
            "subdomain": "b2b101",
            "email": "shoa@softwareag.com",
            "password": "Shoa@001",
            "trialAccount": true,
            "sendWelcomeEmail": 0,
            "isSAGCloudTenant": false,
            "b2bEnabled": false,
            "b2bEDIEnabled": false,
            "number_of_users": 12,
            "ldapUser": false
        }
    }
}
Authorization: Basic Auth : admin@longjump.com/longjump@1234
5. After Successful creation Login to https://b2b101.shoa.com/integration shoa@softwareag.com/Shoa@001
6. Validate for Successful Login
7. RUN docker inspect wmio-enginx
8. Copy the IPv4 Address under nw-external-nginx user networks
7. Run docker exec -it wmic-is bash
8. Edit /etc/hosts file 
9. Add the following entry b2b101.shoa.com <IPAddress>
10. exit from container
11. Run docker exec -it wmic-ctp bash
12. Edit /etc/hosts file 
13. Add the following entry b2b101.shoa.com 127.0.0.1 (if not already present)
14. exit from container
15. Update the tenant id and tenant subdomain in the .env file
17. RUN docker-compose -f ./servers/wmb2b-is/docker-compose.yml up -d
18. RUN docker exec wmio-inginx nginx -s reload
18. Validate localhost:6555 and https://b2b101.shoa.com/b2b shoa@softwareag.com/Shoa@001